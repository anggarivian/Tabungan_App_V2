

<?php $__env->startSection('title'); ?> Laporan Pengajuan - SakuRame <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading mb-2">
    <div class="d-flex justify-content-between ">
        <h3 class="mt-3">Laporan Pengajuan</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-right">
                <?php if(auth()->user()->roles_id == 1): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('kepsek.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 2): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('bendahara.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 3): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('walikelas.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 4): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('siswa.dashboard')); ?>">Dashboard</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page">Laporan Pengajuan</li>
            </ol>
        </nav>
    </div>
</div>
<div class="page-content">
    <div class="card">
        <div class="card-body" style="margin-bottom: -20px">
            <form action="/bendahara/kelola-siswa" method="GET">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-md-6 col-lg-1 mb-2 mb-lg-0">
                            <p class="card-title" style="margin-top: 7px">Filter :</p>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3 mb-2 mb-lg-0">
                            <input type="text" class="form-control" style="padding-right: 1px" name="search" id="search" value="<?php echo e(request('search')); ?>" placeholder="Cari Nama atau Username...">
                        </div>
                        <div class="col-12 col-md-6 col-lg-2 mb-2 mb-lg-0">
                            <select class="form-select" name="kelas" id="kelas">
                                <option value="">Kelas</option>
                                <option value="1A" <?php echo e(request('kelas') == '1A' ? 'selected' : ''); ?>>1 - A</option>
                                <option value="1B" <?php echo e(request('kelas') == '1B' ? 'selected' : ''); ?>>1 - B</option>
                                <option value="2A" <?php echo e(request('kelas') == '2A' ? 'selected' : ''); ?>>2 - A</option>
                                <option value="2B" <?php echo e(request('kelas') == '2B' ? 'selected' : ''); ?>>2 - B</option>
                                <option value="3A" <?php echo e(request('kelas') == '3A' ? 'selected' : ''); ?>>3 - A</option>
                                <option value="3B" <?php echo e(request('kelas') == '3B' ? 'selected' : ''); ?>>3 - B</option>
                                <option value="4" <?php echo e(request('kelas') == '4' ? 'selected' : ''); ?>>4</option>
                                <option value="5" <?php echo e(request('kelas') == '5' ? 'selected' : ''); ?>>5</option>
                                <option value="6" <?php echo e(request('kelas') == '6' ? 'selected' : ''); ?>>6</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-6 col-lg-2 mb-2 mb-lg-0">
                            <select class="form-select" name="status" id="status">
                                <option value="">Status</option>
                                <option value="Aktif" <?php echo e(request('status') == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                                <option value="Non-Aktif" <?php echo e(request('status') == 'Non-Aktif' ? 'selected' : ''); ?>>Non-Aktif</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3 mb-2 mb-lg-0">
                            <select class="form-select" name="sort_penarikan" id="sort_penarikan">
                                <option value="">Urutkan Penarikan</option>
                                <option value="desc" <?php echo e(request('sort_penarikan') == 'desc' ? 'selected' : ''); ?>>Banyak ke Kecil</option>
                                <option value="asc" <?php echo e(request('sort_penarikan') == 'asc' ? 'selected' : ''); ?>>Kecil ke Banyak</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 mb-2 mb-lg-0">
                            <button type="submit" class="btn btn-primary w-100">
                                Cari
                            </button>
                        </div>
                    </div>
                </div>

            </form>
        </div>

        
        <div class="card-body pb-1 pt-3">
            <div class="table-responsive-lg">
                <table class="table table-hover" style="width: 100%">
                    <thead>
                        <tr>
                            <th colspan="1" class="text-center">No.</th>
                            <th class="text-center">ID</th>
                            <th>Nama</th>
                            <th class="text-center">Kelas</th>
                            <th class="text-center">Saldo</th>
                            <th class="text-center">Jumlah Penarikan</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Pembayaran</th>
                            <th class="text-center">Alasan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->user->username); ?></td>
                                <td><?php echo e($pengajuans->user->name); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->user->kelas->name ?? '-'); ?></td>
                                <td class="text-center">Rp. <?php echo e($pengajuans->tabungan->saldo ?? '-'); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->jumlah_penarikan ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($pengajuans->status == 'Pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($pengajuans->status == 'Tolak'): ?>
                                        <span class="badge bg-danger">Tolak</span>
                                    <?php elseif($pengajuans->status == 'Terima'): ?>
                                        <span class="badge bg-success">Terima</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($pengajuans->pembayaran ?? '-'); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->alasan ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Data Kosong</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
                <?php echo e($pengajuan->links('layout.pagination.bootstrap-5')); ?>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\www\Tabungan_App_V2\resources\views/bendahara/laporan/lap_pengajuan.blade.php ENDPATH**/ ?>