

<?php $__env->startSection('title'); ?> Kelola Pengajuan Penarikan - SakuRame <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading mb-2">
    <div class="d-flex justify-content-between ">
        <h3 class="mt-3">Pengajuan Penarikan</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-right">
                <?php if(auth()->user()->roles_id == 1): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('kepsek.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 2): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('bendahara.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 3): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('walikelas.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 4): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('siswa.dashboard')); ?>">Dashboard</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page">Pengajuan</li>
            </ol>
        </nav>
    </div>
</div>
<div class="page-content">
    <div class="card">
        <div class="card-body" style="margin-bottom: -20px">
            <?php if(session('success')): ?>
                <div id="alert" class="alert alert-<?php echo e(session('alert-type')); ?> alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle"></i>
                    <?php echo e(session('alert-message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <script>
                <?php if(session('alert-duration')): ?>
                    setTimeout(function() {
                        document.getElementById('alert').style.display = 'none';
                    }, <?php echo e(session('alert-duration')); ?>);
                <?php endif; ?>
            </script>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show pb-1" role="alert">
                    <strong>Terjadi Kesalahan!</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="d-flex justify-content-between">
                <div class="input-group">
                    <p class="card-title">Data Pengajuan Penarikan Tabungan</p>
                </div>
                <form action="/bendahara/kelola-siswa" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control rounded" style="padding-right: 1px" name="search" id="search" value="<?php echo e(request('search')); ?>" placeholder="Cari..." aria-describedby="button-addon2">
                        <button class="btn btn-primary" type="submit" id="button-addon2">Cari</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body pb-1 pt-3">
            <div class="table-responsive-lg">
                <table class="table table-hover" style="width: 100%">
                    <thead>
                        <tr>
                            <th class="text-center">No.</th>
                            <th class="text-center">ID</th>
                            <th>Nama</th>
                            <th class="text-center">Kelas</th>
                            <th class="text-center">Alasan</th>
                            <th class="text-center">Jumlah Penarikan</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->user->username); ?></td>
                                <td><?php echo e($pengajuans->user->name); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->user->kelas->name); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->alasan); ?></td>
                                <td class="text-center"><?php echo e($pengajuans->jumlah_penarikan ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($pengajuans->status == 'Pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($pengajuans->status == 'Tolak'): ?>
                                        <span class="badge bg-danger">Tolak</span>
                                    <?php elseif($pengajuans->status == 'Terima'): ?>
                                        <span class="badge bg-success">Terima</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-success" data-id="<?php echo e($pengajuans->id); ?>" data-bs-toggle="modal" data-bs-target="#editModal">
                                            Proses
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">Data Kosong</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($pengajuan->links('layout.pagination.bootstrap-5')); ?>

            </div>
        </div>
    </div>
</div>


<div class="modal fade modal-borderless" id="editModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="editModalLabel">Proses Pengajuan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editForm" method="POST" action="<?php echo e(route ('bendahara.pengajuan.terima')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="edit-id">ID</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="text" id="edit-id" class="form-control" name="id"  required readonly hidden>
                            <input type="text" id="edit-username" class="form-control" name="username"  required readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-name">Nama</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="text" id="edit-name" class="form-control" name="name"  required readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-kelas">Kelas</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="text" id="edit-kelas" class="form-control" name="kelas" required readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-alasan">Alasan</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <textarea id="edit-alasan" class="form-control" name="alasan"  rows="3" required readonly></textarea>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-tabungan">Jumlah Tabungan</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="text" id="edit-tabungan" class="form-control" name="tabungan" required readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-jumlah_tarik">Jumlah Penarikan</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="number" id="edit-jumlah_tarik" class="form-control" name="jumlah_tarik" required readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="edit-pembayaran">Pembayaran</label>
                        </div>
                        <div class="col-md-8 form-group">
                            <input type="text" id="edit-pembayaran" class="form-control" name="pembayaran" required readonly>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" id="tolakButton" class="btn btn-light" type="button">Tolak</a>
                    <button type="submit" class="btn btn-primary">Setujui</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('.btn-success').on('click', function() {
            var id = $(this).data('id');
            $.ajax({
                url: "<?php echo e(route('bendahara.pengajuan.getData', '')); ?>/" + id,
                type: 'GET',
                success: function(response) {
                    if(response) {
                        $('#edit-id').val(response.id);
                        $('#edit-username').val(response.username);
                        $('#edit-name').val(response.name);
                        $('#edit-kelas').val(response.kelas);
                        $('#edit-jumlah_tarik').val(response.jumlah_tarik);
                        $('#edit-tabungan').val(response.tabungan);
                        $('#edit-pembayaran').val(response.pembayaran);
                        $('#edit-alasan').val(response.alasan);

                        $('#tolakButton').attr('href', '/bendahara/kelola-pengajuan/tolak/' + response.id);

                    } else {
                        alert('Gagal mengambil data');
                    }
                },
                error: function() {
                    alert('Terjadi kesalahan saat mengambil data');
                }
            });
        });
    });
    function confirmDelete(id) {
        $('#deleteForm').attr('action', '/bendahara/kelola-siswa/hapus/' + id);
        $('#deleteModal').modal('show');
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\www\Tabungan_App_V2\resources\views/bendahara/kelola_pengajuan.blade.php ENDPATH**/ ?>