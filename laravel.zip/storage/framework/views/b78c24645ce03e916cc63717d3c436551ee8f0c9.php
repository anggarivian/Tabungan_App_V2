

<?php $__env->startSection('title'); ?> Stor Tabungan - SakuRame <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading mb-2">
    <div class="d-flex justify-content-between">
        <h3 class="mt-3">Stor Tabungan</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-right">
                <?php if(auth()->user()->roles_id == 1): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('kepsek.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 2): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('bendahara.dashboard')); ?>">Dashboard</a></li>
                <?php elseif(auth()->user()->roles_id == 3): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('walikelas.bendahara')); ?>">Bendahara</a></li>
                <?php elseif(auth()->user()->roles_id == 4): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route ('siswa.dashboard')); ?>">Siswa</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item"><a href="<?php echo e(route ('bendahara.tabungan.index')); ?>">Tabungan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Stor</li>
            </ol>
        </nav>
    </div>
</div>
<div class="page-content">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                    <?php if(session('success')): ?>
                        <div id="alert" class="alert alert-<?php echo e(session('alert-type')); ?> alert-dismissible fade show" role="alert">
                            <i class="bi bi-check-circle"></i>
                            <?php echo e(session('alert-message')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <script>
                        <?php if(session('alert-duration')): ?>
                            setTimeout(function() {
                                document.getElementById('alert').style.display = 'none';
                            }, <?php echo e(session('alert-duration')); ?>);
                        <?php endif; ?>
                    </script>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show pb-1" role="alert">
                            <strong>Terjadi Kesalahan!</strong>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <form id="searchForm">
                        <div class="form-group mb-0">
                            <div class="row">
                                <div class="col-md-4 mb-1">
                                    <div class="input-group mb-3">
                                        <label for="username" class="form-label">Cari ID Tabungan</label>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-1">
                                    <div class="input-group mb-3">
                                        <input type="text" id="username" class="form-control" placeholder="Masukkan ID Tabungan">
                                        <button class="btn btn-primary" type="submit">Cari</button>
                                    </div>
                                </div>
                                <div id="tidak-ada"></div>
                            </div>
                        </div>
                    </form>
                    <form action="<?php echo e(route ('bendahara.tabungan.storTabungan')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                                    <label for="nama">Nama</label>
                                </div>
                                <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                                    <input type="text" hidden class="form-control" id="username2" name="username" readonly>
                                    <input type="text" class="form-control" id="name" name="name" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                                    <label for="kelas">Kelas</label>
                                </div>
                                <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                                    <input type="text" class="form-control" id="kelas" name="kelas" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                                    <label for="jumlah_tabungan">Tabungan Saat Ini</label>
                                </div>
                                <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text" id="basic-addon1">Rp.</span>
                                        <input type="number" class="form-control" id="jumlah_tabungan" name="jumlah_tabungan" readonly >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                                    <label for="jumlah_stor">Jumlah Stor</label>
                                </div>
                                <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text">Rp.</span>
                                        <input type="number" class="form-control" id="jumlah_stor" name="jumlah_stor" placeholder="Masukkan Jumlah Stor" >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                                </div>
                                <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                                    <div class="d-flex justify-content-between">
                                        <a href="<?php echo e(route ('bendahara.tabungan.index')); ?>" type="button" class="btn btn-secondary" style="width: 48%">Kembali</a>
                                        <button type="submit" class="btn btn-primary" style="width: 48%">Stor</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="container ">
                        <div class="d-flex justify-content-center mt-3">
                            <img src="<?php echo e(asset('dist/assets/compiled/jpg/2.jpg')); ?>" height="250px" width="250px" alt="Profile" style="border-radius: 15px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        $('#searchForm').on('submit', function(e) {
            e.preventDefault();

            var username = $('#username').val();

            $.ajax({
                url: "<?php echo e(route('bendahara.search')); ?>",
                method: "GET",
                data: { username: username },
                success: function(data) {
                    if (data) {
                        console.log(data);
                        if(data.name !== 'Tidak Ada' && data.kelas !== 'Tidak Ada' && data.tabungan !== 'Tidak Ada') {
                            $('#name').val(data.name);
                            $('#kelas').val(data.kelas);
                            $('#jumlah_tabungan').val(data.tabungan);
                        } else {
                            $('#tidak-ada').html('<div class="alert alert-danger">Data tidak ditemukan</div>');
                            setTimeout(function() {
                                $('#tidak-ada').empty();
                            }, 2000);
                            $('#name').val('');
                            $('#kelas').val('');
                            $('#jumlah_tabungan').val('');
                        }
                        $('#jumlah_stor').focus();
                    } else {
                        alert('User tidak ditemukan');
                    }
                },
                error: function(xhr, status, error) {
                    alert('Terjadi kesalahan: ' + error);
                }
            });
        });

        $('#username').on('keypress', function(e) {
            if(e.which === 13) {
                $('#jumlah_stor').focus();
            }
        });
    });

    $('#username').on('change', function() {
        $('#username2').val($(this).val());
    });

    $(document).ready(function(){
        setTimeout(function(){
            $('#username').focus();
        }, 500);  // menunda fokus selama 500ms
    });


</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\www\Tabungan_App_V2\resources\views/bendahara/tabungan/stor.blade.php ENDPATH**/ ?>