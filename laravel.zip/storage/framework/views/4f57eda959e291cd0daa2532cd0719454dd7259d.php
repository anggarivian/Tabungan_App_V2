<?php $__env->startSection('content'); ?>
    <h1>Halaman Offline</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\www\Tabungan_App_V2\resources\views/modules/laravelpwa/offline.blade.php ENDPATH**/ ?>