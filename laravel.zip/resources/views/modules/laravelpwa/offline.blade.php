@extends('layouts.app')

@section('content')
    <h1>Halaman Offline</h1>
@endsection
